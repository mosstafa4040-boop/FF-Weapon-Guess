مشروع لعبة خمن سلاح فري فاير - إصدار 2
يحتوي على:
- لعبة HTML مطورة تعمل داخل WebView.
- مؤثرات انتقال وصوت.
- حفظ النقاط محليًا على الجهاز.
- مشروع Android مصدر لتجميع APK.

لإنشاء APK يلزم Android Studio أو بيئة بناء Android متوافقة مع Gradle 8.9 و Android Gradle Plugin 8.7.3.
افتح مجلد المشروع في Android Studio ثم اختر Build > Build APK(s).
ملف APK الناتج يظهر عادة في app/build/outputs/apk/debug/app-debug.apk.
هذا الملف مشروع مصدر وليس APK جاهزًا.
