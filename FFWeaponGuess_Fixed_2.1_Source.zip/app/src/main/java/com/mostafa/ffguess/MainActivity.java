package com.mostafa.ffguess;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().getDecorView().setSystemUiVisibility(
      View.SYSTEM_UI_FLAG_FULLSCREEN |
      View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
      View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    );

    WebView web = new WebView(this);
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);

    // تفعيل نوافذ التأكيد والتنبيه التي تستخدمها أزرار اللعبة.
    web.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this)
          .setMessage(message)
          .setPositiveButton("نعم", (dialog, which) -> result.confirm())
          .setNegativeButton("إلغاء", (dialog, which) -> result.cancel())
          .setOnCancelListener(dialog -> result.cancel())
          .show();
        return true;
      }

      @Override
      public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this)
          .setMessage(message)
          .setPositiveButton("حسنًا", (dialog, which) -> result.confirm())
          .setOnCancelListener(dialog -> result.confirm())
          .show();
        return true;
      }
    });

    web.setBackgroundColor(0xFF100827);
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override
  public void onBackPressed() {
    super.onBackPressed();
  }
}
